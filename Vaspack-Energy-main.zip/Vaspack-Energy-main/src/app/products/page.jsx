import React from 'react'
import Automotive from './components/automotive'

export default function page() {
  return (
    <div>
      <Automotive />
    </div>
  )
}
